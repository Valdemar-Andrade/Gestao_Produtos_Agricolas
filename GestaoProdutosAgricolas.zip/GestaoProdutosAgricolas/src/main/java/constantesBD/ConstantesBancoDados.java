package constantesBD;

public class ConstantesBancoDados {

    public static final String NOME_UTILIZADOR = "postgres";
    public static final String SENHA = "";
    public static final String HOST = "localhost";
    public static final String NOME_BD = "produtos_agricolas";
    public static final int PORTA = 5432;
    
}
